/* 
  Project: cambiar color de un div con valores en un objeto js
  Date: 2024-04-08
*/

// Con claves entre comillas como si fuese un JSON
const colores = {
  "div1": 'red', // "#ff9999", // Rojo
  "div2": "#99ff99", // Verde
  "div3": "#9999ff"  // Azul
};

function cambiarColor(idDiv) {
  const nuevoColor = colores[idDiv];
  document.getElementById(idDiv).style.backgroundColor = nuevoColor;
}

function restablecerColor(idDiv) {
  document.getElementById(idDiv).style.backgroundColor = 'white';
}