/* 
  Project: metodos de string el principito
  Date: 2024-04-05
*/

let principito = "Cuando yo tenía seis años vi en el libro sobre la selva virgen: Historias vividas, una grandiosa estampa. Representaba una serpiente boa comiéndose a una fiera.";



function eliminarSignos(obj, signos) {
  console.log(obj);
  let textoModificado = obj._texto;

  for (let i = 0; i < signos.length; i++) {
    textoModificado = textoModificado.replaceAll(signos[i], "");
  }
  
  // Propiedad creada con notación de corchete
  obj['_textoSinSignos'] = textoModificado;
  obj['totalLetras'] = obj._textoSinSignos.length

  return obj;
}

function contarPalabras (obj) {
  console.log(obj);

  // let palabras =  obj._textoSinSignos.split(" ");
  // console.log(palabras);

  // Propiedad creada con notación de punto
  obj.totalPalabras = obj._textoSinSignos.split(" ").length;
  
  return obj;
}

function crearPropiedadesPalabra(obj) {
  
  let palabras = obj._textoSinSignos.split(" ")
  console.log(palabras);

  for (let i = 0; i < palabras.length; i++) {
    // Propiedad creada con con notación de corchete
    obj['palabra'+(i+1)] = palabras[i];
  }
  
  return obj;
}


let signos = ["{", "}", "[", "]", "(", ")", "¿", "?", "¡", "!", ".", ",", ";", ":", "...", "@", "€", "$", "&", "ç", "º", "ª", "+", "-", "*", "/", "\\", "%", "#", "=", "~", "_", "|", "<", ">", '"', "'", "`", "^", "¨", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9"];

let obj = {};
obj['_texto'] = principito;

obj = eliminarSignos(obj, signos);
console.log("eliminarSignos:", obj);

obj = contarPalabras(obj)
console.log("contarPalabras:", obj);

obj = crearPropiedadesPalabra(obj);
console.log('crearPropiedadesPalabra:', obj);

/**
 * La siguiente opción es válida pero es la menos
 * eficiente ya que al invocar la función eliminarSignos se
 * pasa el arreglo signos y tendría que recorrerlo TODO
 * nuevamente cuando lo que queremos hacer es eliminar un
 * caracter en particular (el espacio en clanco ' ')
 *  
 */ 
signos.push(" ");
console.log(signos);

obj = eliminarSignos(obj, signos);
console.log('eliminarSignos:', obj);

/**
 * Podemos redefinir signos con solo el espacio en blanco
 */

// signos = [" "];
// obj = eliminarSignos(obj, signos);
// console.log('eliminarSignos:', obj);
/**
 * Otra opción sería pasar el caracter como parámetro
 */

// obj = eliminarSignos(obj, " ");
// console.log('eliminarSignos:', obj);


