/* 
  Project: metodos de string
  Date: 2024-04-03
*/

/** 
 * Strings:
 *  - Entre comillas simples o dobles
 *   - Las comillas pueden anidarse:
 *      - Dobles dentro de simples:
 *        'Hola "JavaScript"'
 *      - Simples dentro e dobles:
 *        "Hola 'JavaScript'"
 * 
 *  - Poseen longitud
 *  - Tienen orden
 *  - Son INMUTABLES
*/

let texto = "Hola JavaScript";
let res;

const clg = (param) => console.log(param);

/**
 * Longitud
 */
res = texto.length;
clg(`Longitud: ${res}`);

/**
 * concat() - Une dos o más strings y devuelve un nuevo string.
 */
res = texto.concat(' ').concat('eres maravilloso')
clg(`concat(): ${res}`);

let texto2 = ' pero manejas los datos numéricos de punto flotante de una forma inadecuada'

res = texto.concat(' ').concat('eres maravilloso').concat(texto2)
clg(`concat(): ${res}`);

let num = 3.1256789935
res = texto + ' ' + 'eres maravilloso' + texto2 + ' ' + String(num);
clg(`Concatenando con '+': ${res}`);

/**
 * toLowerCase() - Convierte un string a minúsculas.
 */
clg(`texto: ${texto}`);
res = texto.toLowerCase();
clg(`toLowerCase(): ${res}`);

/**
 * toUpperCase() - Convierte un string a mayúsculas.
 */
res = texto.toUpperCase();
clg(`toUpperCase(): ${res}`);


/***
 * trim() - Elimina los espacios en blanco en ambos 
 * extremos del string.
 */
clg(`texto: ${texto}`);
clg(`texto: ${texto.length}`);

texto = '       ' + texto + '       ';
clg(`texto: ${texto}`);
clg(`texto: ${texto.length}`);

res = texto.trim()
clg(`texto.trim(): ${res}`);
clg(`texto.lenght: ${res.length}`);

texto = res;

/***
 * trimStart() / trimLeft() - Elimina los espacios en blanco 
 * desde el inicio del string.
 */
texto = '       '.concat(texto).concat('       ');
clg(`texto: ${texto}`);
clg(`texto: ${texto.length}`);

res = texto.trimStart()
clg(`texto.trimStart(): ${res}`);
clg(`texto.lenght: ${res.length}`);

texto = res;

/*
* trimEnd() / trimRight() - Elimina los espacios en blanco desde 
* el final del string.
*/
texto = '       '.concat(texto).concat('       ');
clg(`texto: ${texto}`);
clg(`texto: ${texto.length}`);

res = texto.trimEnd();
clg(`texto.trimEnd(): ${res}`);
clg(`texto.lenght: ${res.length}`);

texto = res.trim();

/**
 * startsWith() - Determina si un string comienza con 
 * los caracteres de otro string.
 */
res = texto.startsWith('hola');
clg(`startsWith('hola'): ${res}`);

res = texto.startsWith('Hola');
clg(`startsWith('Hola'): ${res}`);

res = texto.toLowerCase();
res = res.startsWith('hola');
clg(`.toLowerCase().startsWith('hola'): ${res}`)

/**
 * Produce error ya que primero evalúa texto.StartsWidth('hola')
 * y esto produce una salida true o false, estos valores 
 * booleanos no puedes convertirlos a mayúsculas o minúsculas.
 */

// res = texto.startsWith('hola').toLowerCase();
// clg(`.toLowerCase().startsWith('hola'): ${res}`)

/**
 * endsWith() - Determina si un string termina con los 
 * caracteres de otro string.
 */

res = texto.endsWith('t');
clg(`endsWith('t'): ${res}`);

/**
 * search() - Ejecuta una búsqueda de una coincidencia (
 * la primera) entre una expresión regular y este String.
 * 
 * Devuelve -1 si no lo encuentra
 */

clg(texto);
res = texto.search('a');
clg(`search('a'): ${res}`);


res = texto.search('Hola');
clg(`search('Hola'): ${res}`);


res = texto.search('var');
clg(`search('var'): ${res}`);

/*
* match() - Se utiliza para buscar coincidencias de una 
* expresión regular dentro de un string.
*/

/**
 * Expresiones regulares en JS
 * /patron/bandera ← Pa
 * /patron/ ← Va entre diagonales
*/

res = texto.match(/a/);
clg(`match(/a/): ${res}`);
clg(`typeof(res): ${typeof(res)}`);

/**
 * La bandera 'g' realiza la búsqueda del
 * 'patron' en toda el texto sin detenerse
 * solo en la primera ocurrencia.
 * 
 * Retorna un array
 * Devuelve null si no existe la coincidencia
*/

res = texto.match(/a/g);
clg(`match(/a/g): ${res}`);
clg(`typeof(res): ${typeof(res)}`);

res = texto.match(/j/g);
clg(`match(/j/g): ${res}`);
clg(`typeof(res): ${typeof(res)}`);

res = texto.match(/j/gi);
clg(`match(/j/g): ${res}`);
clg(`typeof(res): ${typeof(res)}`);

/**
 * matchAll() - Devuelve un iterador con todas las coincidencias
 * de una expresión regular.
 * 
 * Retorna un array de arrays
 * 
 * Si NO existe coincidencia devuelve un 
 * array vacío
*/

let iterador = texto.matchAll(/a/g);
clg(`matchAll(/a/g): ${iterador}`);

res = Array.from(iterador);
clg(`Array.from(iterador): ${res}`);


iterador = texto.matchAll(/x/g);
clg(`matchAll(/x/g): ${iterador}`);

res = Array.from(iterador);
clg(`Array.from(iterador): ${res}`);

/**
 * includes() - Determina si un string contiene una secuencia
 * de caracteres.
 */

res = texto.includes('Jav');
clg(`includes('Jav'): ${res}`);

res = texto.includes('Rust');
clg(`includes('Rust'): ${res}`);


/**
 * NOTA:
 *  Recorrer un String
 */

clg('>>> for clásico')
for (let i = 0; i < texto.length; i++) {
  const elemento = texto[i];
  clg(`elemento: ${texto[i]}`)
}


clg('>>> for...of')
for (const elemento of texto) {
  clg(`elemento: ${elemento}`)
}

/**
 * substring() - Devuelve un subconjunto de un objeto String.
 * 
 * texto.substring(DESDE índice X, HASTA índice Y SIN INCLUIRLO)
 * 
 * Devuelve un string vacío si NO encuentra
 * el substring
 */

clg(texto)
res = texto.substring(0, 4);
clg(`substring(2, 7): ${res}`)

res = texto.substring(100, 400);
clg(`substring(2, 7): ${res}`)
clg(`typeof(res): ${typeof(res)}`);

/**
 * Mostrando los caracteres de un array
 * mediante su índice
 * 
 * Si no existe el índice devuelve 'undefined'
 */
res = texto[0]
clg(`texto[0]: ${res}`)

res = texto[11]
clg(`texto[11]: ${res}`)

res = texto[25] // <- no existe = undefined
clg(`texto[25]: ${res}`)

res = texto[-1]
clg(`texto[-1]: ${res}`)


/**
 * indexOf() - Devuelve el índice de la primera aparición de un valor especificado, o -1 si no se encuentra.
 */

clg(texto)
res = texto.indexOf('J');
clg(`indexOf('J'): ${res}`)

/**
* lastIndexOf() - Devuelve el último índice en el que se puede encontrar un valor especificado, o -1 si no se encuentra.
*/

res = texto.lastIndexOf('J');
clg(`lastIndexOf('J'): ${res}`);


res = texto.indexOf('a');
clg(`indexOf('a'): ${res}`)

res = texto.lastIndexOf('a');
clg(`lastIndexOf('a'): ${res}`);



/**
* padEnd() - Rellena el string actual con otro string (varias veces, si es necesario) hasta que el string resultante alcance la longitud dada.
*/

res = texto.padEnd(20,".");
clg(`padEnd(20,"."): ${res}`);
clg(res.length);


/**
 * padStart() - Similar a padEnd(), pero rellena al principio.
 */

res = texto.padStart(20,".");
clg(`padStart(20,"."): ${res}`);
clg(res.length);

// ¿Y si la cantidad de caracteres es inferior
// a la longitud de la cadena?
res = texto.padStart(10,".");
clg(`padStart(20,"."): ${res}`);
clg(res.length);


// Así NO ;p
res = texto.padStart(25,".").padEnd(25,".") 
clg(`.padStart(25,".").padEnd(25,"."): ${res}`);
clg(res.length);

res = "".padStart(5,".") + texto + "".padEnd(5,".") 
clg(`${res}`);

clg(res.length);

res = ''.padStart(5, ".").concat(texto).concat(''.padEnd(5, "."));
clg(`${res}`);



/**
 * repeat() - Devuelve un nuevo string que contiene un número especificado de copias del string en el que se llama.
*/

res = texto.repeat(3);
clg(`repeat(3): ${res}`)

/**
 * replace() - Devuelve un nuevo string con algunas o todas las coincidencias de un patrón reemplazadas por un reemplazo.
*/

res = texto.replace("Hola", "Helloooou");
clg(`texto: ${texto}`)
clg(`replace("Hola", "Heloooou"): ${res}`)


res = texto.replace('a', 'x');
clg(texto);
clg(`replaceAll('a', 'x'): ${res}`)



res = "Buenos días queridos alumnos".replace("alumnos", "alumnos / alumnas / alumnes");

clg(`replace("alumnos", "alumnos / alumnas / alumnes"): ${res}`)

/**
 * replaceAll() - Similar a replace(), pero reemplaza todas las coincidencias.
 * 
 */
res = texto.replaceAll('a', 'x');
clg(texto);
clg(`replaceAll('a', 'x'): ${res}`)

/**
 * slice() - Extrae una sección de un string y devuelve un 
 * nuevo string.
 * 
 * slice(DESDE índice X, HASTA índice Y - sin incluirlo)
 */

res = texto.slice(0,3);
clg(`slice(0,4): ${res}`)

/**
 * split() - Divide un objeto de tipo String en un array 
 * de strings mediante la separación del string en subcadenas.
*/
res = texto.split(" ");
clg(`split(" "): ${res}`)

res = texto.split("a");
clg(`split("a"): ${res}`)

/** 
 * charAt(n)
 * Devuelve el carácter en la posición especificada.
 */
res = texto.charAt(0);
clg(`charAt(0): ${res}`);

/**
 * charCodeAt(0) - Devuelve el código Unicode del 
 * carácter en la posición especificada.
 */ 
res = texto.charCodeAt(1);
clg(`charCodeAt(0): ${res}`);

/**
 * valueOf() - Devuelve el valor primitivo de un objeto String.
 */

res = texto.valueOf();
clg(`valueOf(): ${typeof(res)} -> ${res}`);

texto = 125;
res = texto.valueOf();
clg(`valueOf(): ${typeof(res)} -> ${res}`);

texto = true;
res = texto.valueOf();
clg(`valueOf(): ${typeof(res)} -> ${res}`);

texto = ['e1', 'e2'];
res = texto.valueOf();
clg(`valueOf(): ${typeof(res)} -> ${res}`);


texto = {
  e1: true, 
  e2: false
};

texto = 1234567890;
res = texto.valueOf();
clg(`valueOf(): ${typeof(res)} -> ${res}`);

typeof(texto);

if (typeof(texto) == 'number') {
   texto = String(texto);
   res = texto.valueOf();
   clg(`valueOf(): ${typeof(res)} -> ${res}`);
}

texto = ['uno', 'dos'];
texto += 'aaaaaaaaa';
res = texto.valueOf();
clg(`valueOf(): ${typeof(res)} -> ${res}`);

res += 'aaaaaaaaa';
console.log(res)

let obj = new String("Hola mundo");
clg(`valueOf(): ${typeof(obj)} -> ${obj}`);
console.log(typeof(obj.valueOf()), obj.valueOf());


let strObj = new String("Hola mundo"); // Esto es un objeto de cadena
let strPrimitive = "Hola mundo"; // Esto es una cadena primitiva

console.log(strObj === strPrimitive); // Esto devuelve false porque uno es un objeto y el otro es una primitiva
console.log(strObj.valueOf() === strPrimitive); // Esto devuelve true, porque ambos son valores primitivos

if (strObj == strPrimitive) {
  console.log("Hellooou");
} else {
  console.log("Hasta la vista baby!");
}

if (strObj === strPrimitive) {
  console.log("Hellooou");
} else {
  console.log("Hasta la vista baby!");
}

if (strObj.valueOf() === strPrimitive) {
  console.log("Hellooou");
} else {
  console.log("Hasta la vista baby!");
}