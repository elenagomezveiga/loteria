/* 
  Project: metodos de string quijote metodo 2
  Date: 2024-04-04
*/

let principito = "En un lugar de la Mancha, de cuyo nombre no quiero acordarme, no ha mucho tiempo que vivía un hidalgo de los de lanza en astillero, adarga antigua, rocín flaco y galgo corredor. Una olla de algo más vaca que carnero, salpicón las más noches, duelos y quebrantos los sábados, lantejas los viernes, algún palomino de añadidura los domingos, consumían las tres partes de su hacienda. El resto della concluían sayo de velarte, calzas de velludo para las fiestas, con sus pantuflos de lo mesmo, y los días de entresemana se honraba con su vellorí de lo más fino. Tenía en su casa una ama que pasaba de los cuarenta, y una sobrina que no llegaba a los veinte, y un mozo de campo y plaza, que así ensillaba el rocín como tomaba la podadera. Frisaba la edad de nuestro hidalgo con los cincuenta años; era de complexión recia, seco de carnes, enjuto de rostro, gran madrugador y amigo de la caza. Quieren decir que tenía el sobrenombre de Quijada, o Quesada, que en esto hay alguna diferencia en los autores que deste caso escriben; aunque, por conjeturas verosímiles, se deja entender que se llamaba Quejana. Pero esto importa poco a nuestro cuento; basta que en la narración dél no se salga un punto de la verdad." 
+
"Es, pues, de saber que este sobredicho hidalgo, los ratos que estaba ocioso, que eran los más del año, se daba a leer libros de caballerías, con tanta afición y gusto, que olvidó casi de todo punto el ejercicio de la caza, y aun la administración de su hacienda. Y llegó a tanto su curiosidad y desatino en esto, que vendió muchas hanegas de tierra de sembradura para comprar libros de caballerías en que leer, y así, llevó a su casa todos cuantos pudo haber dellos; y de todos, ningunos le parecían tan bien como los que compuso el famoso Feliciano de Silva, porque la claridad de su prosa y aquellas entricadas razones suyas le parecían de perlas, y más cuando llegaba a leer aquellos requiebros y cartas de desafíos, donde en muchas partes hallaba escrito: La razón de la sinrazón que a mi razón se hace, de tal manera mi razón enflaquece, que con razón me quejo de la vuestra fermosura. Y también cuando leía: ...los altos cielos que de vuestra divinidad divinamente con las estrellas os fortifican, y os hacen  merecedora del merecimiento que merece la vuestra grandeza."
+
"Con estas razones perdía el pobre caballero el juicio, y desvelábase por entenderlas y desentrañarles el sentido, que no se lo sacara ni las entendiera el mesmo Aristóteles, si  resucitara para sólo ello. No estaba muy bien con las heridas que don Belianís daba y recebía, porque se imaginaba que, por grandes maestros que le hubiesen curado, no dejaría de tener el rostro y todo el cuerpo lleno de cicatrices y señales. Pero, con todo, alababa en su autor aquel acabar su libro con la promesa de  aquella inacabable aventura, y muchas veces le vino deseo de tomar la pluma y dalle fin al pie de la letra, como allí se promete; y sin duda alguna lo hiciera, y aun saliera con ello, si otros mayores y continuos pensamientos no se lo estorbaran. Tuvo muchas veces competencia con el cura de su lugar -que era hombre docto, graduado en Sigüenza-, sobre cuál había sido mejor  caballero: Palmerín de Ingalaterra o Amadís de Gaula; mas maese Nicolás, barbero del mesmo pueblo, decía que ninguno llegaba al Caballero del Febo, y que si alguno se le podía comparar, era don Galaor, hermano de Amadís de Gaula, porque tenía muy acomodada condición para todo; que no era caballero melindroso, ni tan  llorón como su hermano, y que en lo de la valentía no le iba en zaga.";



function eliminarSignos(obj, signos) {
  let textoModificado = obj._texto;

  for (let i = 0; i < signos.length; i++) {
    textoModificado = textoModificado.replaceAll(signos[i], "");
  }
  
  obj['_textoSinSignos'] = textoModificado;

  return obj;
}

function contar(obj, caracteres) {
  // console.log(obj);
  // console.log(texto);
  // console.log(caracteres);

  for (const caracter of caracteres) {
    const regex = new RegExp(caracter, 'g');
        
    //const regex = new RegExp(caracter, 'gi');
    // obj[c aracter] = texto.match(regex).length;

    
    if (obj._textoSinSignos.match(regex)) {
      obj[caracter] = obj._textoSinSignos.match(regex).length;
    } else {
      obj[caracter] = 0;
    }
  }

  return obj
}

let signos = ["{", "}", "[", "]", "(", ")", "¿", "?", "¡", "!", ".", ",", ";", ":", "...", "@", "€", "$", "&", "ç", "º", "ª", "+", "-", "*", "/", "\\", "%", "#", "=", "~", "_", "|", "<", ">", '"', "'", "`", "^", "¨", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9"];

let obj = {};
obj['_texto'] = quixote;

console.log(obj);

obj = eliminarSignos(obj, signos);

const vocales = ["A","E","I","O","U","a", "e", "i", "o", "u", "Á","É","Í","Ó","Ú","Ü","á", "é", "í", "ó", "ú", "ü"];


obj = contar(obj, vocales);
console.log(obj)

console.log('>>> for...in');

for (const clave in obj) {
  console.log(clave,":", obj[clave])
}


let totalVocales = 0;

console.log('>>> for...in');
for (const clave in obj) {
  if (clave == "_texto" || clave == "_textoSinSignos") {
    console.log(`No voy a sumar esto: ${clave}`);
  } else {
    console.log(obj[clave]);
    totalVocales += Number(obj[clave]);
  }
}

console.log('El total de vocales en este texto es de:', totalVocales);

