/* 
  Project: practica arrays y objetos
  Date: 2024-04-05
*/

console.log('>>> Arreglos: Añadir elementos');
let arr = [];
let str = "Este es un curso de JavaScript";


// Añadiendo elementos al arreglo

// Por posición

console.log('>>> Arreglos: Añadir elementos por posición');
arr[0] = str;
console.log(arr);


// Por método .push()
console.log('>>> Arreglos: Añadir elementos - método .push()');
arr = [];
arr.push(str);
console.log(arr);


// Añadir cada uno de los caracteres de un string
console.log('>>> Arreglos: Añadir elementos de otro string');

// Recorriendo el string y añadiendo cada caracter al array
// Con un for clásico


arr = [];
str = "Este es maravilloso curso de JavaScript en que mis alumnos nunca se estresan y aprenden mogollón"

for (let i = 0; i < str.length; i++) {
  console.log(str[i]);
  arr.push(str[i])
}


// Con un for...of
console.log('>>> Arreglos: mediante for...of');
for (const caracter of str) {
  // console.log(caracter);
  arr.push(caracter)
}

console.log("String:", str.length, str);
console.log("Array:", arr.length, arr);

console.log('>>> Arreglos: Eliminar elementos');

// Eliminar un elemento del arreglo
// Eliminar el último elemento
console.log('>>> Arreglos: Eliminar último elemento - método .pop()');
res = arr.pop();
console.log("Elemento eliminado:", res);
console.log("Array:", arr.length, arr);

// Eliminar el primer elemento del arreglo
console.log('>>> Arreglos: Eliminar primer elemento - método .shift()');
res = arr.shift()
console.log("Elemento eliminado:", res);
console.log("Array:", arr.length, arr);

// Eliminar un elemento en el índice X del arreglo
console.log('>>> Arreglos: Eliminar un elemento X elemento - método .splice()');
res = arr.splice(4,2);
console.log("Elemento eliminado:", res);
console.log("Array:", arr.length, arr);



arr = ['a', 'e', 'i', 'o', 'u'];

console.log('>>> Arreglos: Añadir elementos');
// Añadir elementos al arreglo

// Al final del arreglo
console.log('>>> Arreglos: Añadir elementos al final');
res = arr.push('elemento al final')
console.log("Elemento añadido:", res);
console.log("Array:", arr.length, arr);


// Al inicio del arreglo
console.log('>>> Arreglos: Añadir elementos al inicio');
res = arr.unshift('elemento al inicio')
console.log("Elemento añadido:", res);
console.log("Array:", arr.length, arr);

// Añadir un elemento en índice X del arreglo
console.log('>>> Arreglos: Añadir elementos en una posición determinada');
res = arr.splice(3, 0, "elemento en índice X")
console.log("Elemento añadido:", res);
console.log("Array:", arr.length, arr);


// Sumar arreglos
console.log('>>> Arreglos: Sumar/Concatenar arreglos');
let arr1 = [1,2,3];
let arr2 = ["a","b","c"];


// El siguiente procedimiento NO concatena arrays
console.log('El siguiente procedimiento NO concatena arrays');
arr = arr1 + arr2;
console.log("arr1", arr1);
console.log("arr2", arr2);
console.log("Suma de arreglos (concatenación)", arr, typeof(arr), "← No funciona, concatenación engañosa");

// Este procedimiento SI concatena 

console.log('>>> Arreglos: Sumar/Concatenar arreglos - método .concat()');
arr = arr1.concat(arr2);
console.log("Suma de arreglos (concatenación)", arr, typeof(arr));


// Concatenar recorriendo cada arreglo y mediante el método push()
console.log('>>> Arreglos: Sumar/Concatenar 2 arreglos en un nuevo arreglo');
arr = [];

for (const e of arr1) {
  arr.push(e);
}

for (const e of arr2) {
  arr.push(e);
}
console.log("Suma de arreglos (concatenación)", arr, typeof(arr));


console.log('>>> Restar arreglos');
console.log('>>> Restar arreglos: Obtención de conjunto');
// Restar dos arrays con la finalidad de crear un array tipo conjunto

arr1 = [1,2,3,4];
arr2 = [2,3,4,1,5,6,3,2,4,7];

arr = arr1.concat(arr2);
console.log(arr);

miSet = new Set(arr);
console.log(miSet);

arr = [];

for (const e of miSet) {
  arr.push(e);
}

console.log(arr);


console.log('>>> Restar arreglos: Resta de valores');
// Restar dos arrays con la finalidad obtener la resta 
// de los valores contenidos en cada uno de sus índices

console.log('>>> Restar arreglos: Resta de valores con arrays del mismo tamaño');
// Arreglos con el mismo tamaño
arr1 = [7,9,11]
arr2 = [2,18,3]

arr = []

for (let i = 0; i < arr1.length; i++) {
  arr.push(arr1[i] - arr2[i])
}

console.log(arr1);
console.log(arr2);
console.log(arr);


console.log('>>> Restar arreglos: Resta de valores con arrays de diferente tamaño');
// Arreglod diferente tamaño

console.log("---->");

arr1 = [7,9,11,0]
arr2 = [2,18,3,15]

function difElementos(arrX, arrY) {
  return arrX.length - arrY.length;
}


function restarArreglos (arrX, arrY) {
    let arr = [];
    for (let i = 0; i < arrX.length; i++) {
      arr.push(arrX[i] - arrY[i])
    }
    return arr;
}

if (arr1.length > arr2.length) {
  console.log("arr1 > arr2");
  res = difElementos(arr1, arr2)
  console.log("Diferencia de elementos:", res);

  for (let i = 0; i < res; i++) {
    arr2.push(0);
  }

  arr = restarArreglos(arr1, arr2)

} else if (arr2.length > arr1.length) {
  console.log("arr2 > arr1");
  res = difElementos(arr2, arr1)
  console.log("Diferencia de elementos:", res);

  for (let i = 0; i < res; i++) {
    arr1.push(0);
  }

  arr = restarArreglos(arr2, arr1)
} else {

  console.log("arr2 = arr1");
  res = difElementos(arr1, arr2)
  
  console.log("Diferencia de elementos:", res);

  arr = restarArreglos(arr1, arr2)
}

console.log(arr1);
console.log(arr2);
console.log(arr);

// Romper referencia en arreglos
console.log('>>> Arreglos: Romper referencia');

let arrX = [0, 1, 2];
let arrY = arrX; // Creación de arreglo arrY por referencia

arrX.push(3)
console.log('arrX:', arrX);
console.log('arrY:', arrY);

let arrZ = arrX.slice(); // Creación de nuevo arreglo sin
                         // compartir referencia

             
arrY.push(4)

console.log('arrX:', arrX);
console.log('arrY:', arrY);
console.log('arrZ:', arrZ);


// Objetos:
console.log('>>> Objetos');
console.log('>>> Objetos: Objeto vacío');

let obj1 = {};
console.log('obj1', obj1, typeof(obj1));

// Añadir elementos
console.log('>>> Objetos: Añadir elementos - notación de punto');

obj1.edad = 18;
console.log('obj1', obj1);

console.log('>>> Objetos: Añadir elementos - notación de corchete');

obj1['color'] = 'verde';
console.log('obj1', obj1);

// Eliminar un elemento de un objeto
//  Puedes utilizar notación de punto o de corchete

console.log('>>> Objetos: Eliminar elemento');
res = obj1.color;

delete obj1.color;

console.log('res', res);
console.log('obj1', obj1);


// Romper referencia
// Superficial - NO rompe referencias a objetos

console.log('>>> Objetos: Romper referencia - SUPERFICIAL - spread operator');
arr = [1,2,3];

obj1 = {
  nombre: 'JC',
  arreglo: arr
}

console.log('arr', arr);
console.log('obj1', obj1);


arr.push('nuevo');

console.log('arr', arr);
console.log('obj1', obj1);


let objSuperficial = {...obj1};

arr.push('otro elemento');

console.log('arr', arr);
console.log('obj1', obj1);
console.log('objSuperficial', objSuperficial);


console.log('>>> Objetos: Romper referencia - SUPERFICIAL - assign()');

objAssign = Object.assign({}, obj1);

arr.push('otro elemento más');

console.log('arr', arr);
console.log('obj1', obj1);
console.log('objSuperficial', objSuperficial);
console.log('objAssign', objAssign);


// Profunda - SI rompe referencias a objetos
console.log('>>> Objetos: Romper referencia - PROFUNDA - JSON');

objJSON = JSON.parse(JSON.stringify(obj1));

arr.splice(arr.length-2, 1);

console.log('arr', arr);
console.log('obj1', obj1);
console.log('objSuperficial', objSuperficial);
console.log('objAssign', objAssign);
console.log('objJSON', objJSON);

// Recorrer un objeto
console.log('>>> Objetos: for...in - Recorrer un objeto vacío');

objVacio = {};

for (const key in objVacio) {
  console.log(key); // No mostrará claves (keys)
}


console.log('>>> Objetos: for...in - Recorrer un objeto NO vacío');

for (const key in obj1) {
  //console.log(`Key: ${key} : ${obj1[key]}`);
  console.log("Key: " + key + ": " + obj1[key]);
}


console.log('>>> Objetos: Object.keys()');
res = Object.keys(obj1)
console.log('res', res, typeof(res));

console.log('>>> Objetos: Object.values()');
res = Object.values(obj1)
console.log('res', res, typeof(res));


console.log('>>> Objetos: Object.entries()');
res = Object.entries(obj1)
console.log('res', res, typeof(res));

console.log('>>> Objetos: Los objetos en JS no poseen índices');

// En el siguiente caso las claves del objetos son numéricoas
// pero esto no significa que sean un índice tal como se 
//maneja en los arrays

let objN = {
  0: 'Propiedad 0',
  1: 'Propiedad 1',
  2: 'Propiedad 2',
}

for (const key in objN) {
  console.log(key);
}

console.log(objN.length)


