/* 
  Project: variables declaracion y ambito
  Date: 2024-04-01
*/

console.log('>>> demoVar: ');
/**
 * Una variable declarada con 'var' es declarada
 * en el ámbito global y puede ser modificada 
 * en el ámbito global y/o local
 */

var demoVar = 10; // Variable pública en 
                  // el ámbito global

console.log(demoVar);  

// Modificación en ámbito global
demoVar = 30;
console.log(demoVar);                   

function funcDemoVar(num) {
  // Modificación en ámbito local
  demoVar = num;
  return demoVar;
}

console.log(funcDemoVar(50));



console.log('>>> demoLet: ');
/**
 * Una variable declarada con 'let' pertenece a
 * un bloque (ámbito global o local)
 */
let demoLet = 20; //Declarada en ámbito global
console.log(demoLet);           

// Modificación en ámbito global
demoLet = 40;
console.log(demoLet);        


function funcDemoLet(num) {
  // Modificación en ámbito local
  demoLet = num;
  return demoLet;
}

console.log(funcDemoLet(60));


console.log('>>> demoLetLocal: ');

let demoLetLocal = 99; // Declarada en ámbito global


function funcDemoLetVariableLocal() {
  let demoLetLocal = 100; // Declarada en ámbito local
  return demoLetLocal;
}

console.log(demoLetLocal, 'GLOBAL'); // <- Global

console.log(funcDemoLetVariableLocal(), 'LOCAL'); // <-- Local

console.log(demoLetLocal, 'GLOBAL'); // <-- Global

demoLetLocal = 115; // <-- Global
console.log(demoLetLocal, 'GLOBAL'); // <-- Global

console.log(funcDemoLetVariableLocal(), 'LOCAL'); // <-- Local


console.log('>>> MI_CONSTANTE: ');
/**
 * Espacio de memoria SOLO LECTURA en el cual se
 * almacenan datos
 */

const MI_CONSTANTE = 90;

MI_CONSTANTE = 100;