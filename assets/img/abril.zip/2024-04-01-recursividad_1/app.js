/* 
  Project: recursividad 1
  Date: 2024-04-01
*/

function menosUno(num) {
  console.log(num, "Parámetro");
  num = num - 1;
  // console.log(num, "Calculado");

  if (num >= 0) {
    menosUno(num);
  } else {
    console.log("Se acabó la recursión");
  }
}

menosUno(5);