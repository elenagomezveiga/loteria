/* 
  Project: hoisting o izamiento
  Date: 2024-04-01
*/

/**
 * El izamiento o "hoisting" en JavaScript es un comportamiento del lenguaje por el cual las declaraciones de variables (con var) y funciones son movidas al inicio de su ámbito (scope) antes de que el código sea ejecutado. 
 * 
 * Esto significa que las variables y funciones pueden ser referenciadas antes de que sean declaradas en el código, aunque existen algunas peculiaridades dependiendo de cómo se declaren.
 */


/**
 * Variables
 * 
 * Cuando se declara una variable con 'var', 
 * JavaScript la inicializa con el valor 
 * 'undefined' al inicio de su ámbito. Esto 
 * permite que la variable sea usada antes de su 
 * declaración explícita. 
 *
 * Sin embargo, si se utilizan 'let' o 'const' 
 * para declarar variables, el izamiento ocurre
 * de manera diferente: estas declaraciones no 
 * son inicializadas al inicio del ámbito, lo que 
 * lleva a un error de referencia si se intentan 
 * usar antes de su declaración.
 */

console.log(">>> Variables con 'var'");

console.log(miVar);
console.log('Vamos a intentarlo');
var miVar = 10;
console.log(miVar);


console.log(">>> Variables con 'let'");
console.log(">>> Se produce un ERROR. Observa el código fuente");

// console.log(miLet);
// console.log('Vamos a intentarlo');
// let miLet = 15;
// console.log(miLet);

/**
 * Funciones
 * 
 * En el caso de las funciones, las declaraciones
 * de función (function declarations) son 
 * completamente izadas, lo que significa que 
 * pueden ser invocadas antes de ser declaradas 
 * en el código. 
 *
 * Sin embargo, las expresiones de función 
 * (function expressions), ya sean nombradas o 
 * anónimas, no se benefician del izamiento de la 
 * misma manera, especialmente si se asignan a 
 * variables usando let o const.
 */


console.log(">>> Declaración de funciones:");

miFuncion(); // Llamando a la función antes de
             // ser declarada

function miFuncion() {
    console.log("Hola mundo");
}

/**
 * Expresiones de función:
 * 
 * Las expresiones de función en JavaScript son
 * una forma de definir funciones, en la cual la
 * función se trata como un valor que puede ser 
 * asignado a una variable. 
 * 
 * A diferencia de las declaraciones de función,
 * donde el nombre de la función es obligatorio
 * y el cuerpo de la función se define dentro de
 * bloques de código {}, en las expresiones de 
 * función, la definición de la función se trata 
 * como un valor que puede ser asignado, pasado 
 * como argumento a otras funciones, etc. 
 * 
 * Las  expresiones de función pueden ser 
 * anónimas (sin nombre) o nombradas.
 */

/**
 * Expresiones de Función Anónimas
 * 
 * Una expresión de función anónima no tiene un
 * nombre. 
 * 
 * Por lo tanto, si quieres referirte a la 
 * función desde sí misma (por ejemplo, para la 
 * recursividad), necesitarías asignarla a una 
 * variable o usar argumentos de función 
 * especiales como arguments.callee, aunque esto 
 * último no es recomendado en el uso moderno de 
 * JavaScript.
 */

//saludo(); // Produce ERROR
const saludo = function() {
    console.log("Hola Mundo");
};
saludo(); // Invoca la función. Salida: "Hola Mundo"

/**
 * Expresiones de Función Nombradas
 * 
 * Las expresiones de función también pueden 
 * tener un nombre. 
 * 
 * Esto permite referenciar la función desde sí 
 * misma, lo cual es útil para la recursividad, 
 * entre otros usos. El nombre es local solo al 
 * cuerpo de la función.
*/


let factorial = function calculoFactorial(n) {
    if (n <= 1) return 1;
    return n * calculoFactorial(n - 1);
};
console.log(factorial(5)); // Salida: 120


/**
 * Comparación con Declaraciones de Función
 * 
 * A diferencia de las declaraciones de función,
 * donde el motor de JavaScript realiza un 
 * "hoisting" (izamiento) de la función completa 
 * al inicio de su ámbito, permitiendo que la 
 * función sea utilizada antes de su declaración, 
 * las expresiones de función asignadas a 
 * variables con let o const no se benefician de 
 * este comportamiento de la misma manera. 
 * 
 * En el caso de let y const, solo el 
 * identificador de la variable es izado, pero no 
 * se inicializa con la función HASTA que el 
 * código se ejecuta en su ubicación respectiva. 
 * 
 * Esto significa que si intentas invocar una 
 * función asignada a una variable mediante una 
 * expresión de función antes de su declaración, 
 * obtendrás un error.
 */

console.log(saludo2()); // Error: Cannot access 'saludo' before initialization
let saludo2 = function() {
    return "Hola Mundo";
};

/**
 * En este caso, JavaScript sabe que saludo2 
 * existe, pero aún no se ha inicializado con la
 * función porque let (al igual que const) no
 * inicializa la variable HASTA que se alcanza su 
 * declaración. 
 * 
 * Esto es diferente de cómo funciona el 
 * izamiento con var o con declaraciones de 
 * función, donde el valor o la función están 
 * disponibles antes de su declaración explícita 
 * en el código.
 */


