/* 
  Project: datos numéricos
  Date: 2024-04-01
*/

function datosNumericos(num) {
  console.log(`Número: ${num}. Tipo: ${typeof(num)}`);
}

datosNumericos(-1);
datosNumericos(0);
datosNumericos(1);

datosNumericos(-3.141527);
datosNumericos(-0.00);
datosNumericos(0.00);
datosNumericos(3.141527);


datosNumericos(BigInt(-9007199254740991));
datosNumericos(BigInt(9007199254740991));

datosNumericos(9007199254740991000000000000);


console.log('0.5 - 0.4 = ', 0.5 - 0.4);
console.log('0.4 - 0.3 = ', 0.4 - 0.3);


// Determinar decimales
let miNumero = prompt("Introduce un número:" );
let miNumeroString;

if (typeof(miNumero) == "number") {
  console.log("Es Número");
  miNumeroString = String(miNumero);
} else {
  console.log("Es String");
  miNumeroString = miNumero;
}

res = miNumeroString.split(".");
console.log(res);

if (res.length == 1) {
  console.log("No posee decimales");
} else if (res.length == 2){
  let decimales = res[1].length;
  console.log(`El número ${miNumero} posee ${decimales} decimales`);

  let multiplicador = '1';
  
  for (let i = 0; i < decimales; i++) {
    multiplicador += '0'
  }

  console.log(multiplicador, typeof(multiplicador));

  console.log(Number(miNumero) * Number(multiplicador));
}



